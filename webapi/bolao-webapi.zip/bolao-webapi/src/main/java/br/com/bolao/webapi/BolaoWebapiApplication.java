package br.com.bolao.webapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BolaoWebapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BolaoWebapiApplication.class, args);
	}
}
